<?php
include('header.php');
?>

<!-- Main -->
<div class="container-fluid">
    <div class="row">
        <?php include('side_menu.php');?> 

       
        <div class="col-sm-9">

          
            <a href="#"><strong><i class="glyphicon glyphicon-dashboard"></i> My Dashboard</strong></a>
            <hr>

           this is dashboard 


        
            
        </div>
        <!--/col-span-9-->
    </div>
</div>
<!-- /Main -->

<?php
include('footer.php');
?>
        
    </body>
</html>
